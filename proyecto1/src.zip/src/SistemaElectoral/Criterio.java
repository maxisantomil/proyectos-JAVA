package SistemaElectoral;

public interface Criterio {
	
	public boolean Cumple(ElementSE e); 
}
